# Criterios y convocatoria

## Perfil didáctico inicial
Convocatoria: primera, según identificación proporcionada por el instructor. Algunos nombres de expedientes contienen 2026. Registra la discrepancia documental sin reasignarlos automáticamente a la segunda convocatoria. El perfil debe validarse antes de uso institucional.
Área: educación y participación comunitaria.
Fuente: INICIATIVAS-DE-educacion-Enfoque-y-Criterios.pdf, páginas 3 y 4, en Normativa/SUBVENCIONES. Enlace: https://galapagoslifefund.org.ec/es/wp-content/uploads/sites/2/2024/12/INICIATIVAS-DE-educacion-Enfoque-y-Criterios.pdf

| Criterio | Peso |
|---|---:|
| Impacto en la comunidad | 20% |
| Impacto en conservación marina | 25% |
| Capacidad técnica | 15% |
| Género y diversidad | 15% |
| Escalabilidad y replicación | 5% |
| Viabilidad | 15% |
| Innovación | 5% |

Estos pesos suman 100%. No se ha incorporado una escala de puntuación ni un umbral de aprobación institucional. Usa evaluación cualitativa hasta recibirlos.

## Nueva convocatoria
Antes de analizar expedientes nuevos, reemplaza el perfil inicial usando las bases aportadas para esa convocatoria. Registra nombre, fechas, versión y fuente, prioridades y subtemas, solicitantes elegibles, categorías y topes, duración, cofinanciación, documentos exigibles por etapa, exclusiones, criterios y pesos, escala y umbrales si existen, órgano de decisión y reglas presupuestarias.
Incluye documento y página para cada regla. Mantén una lista de cambios respecto del perfil anterior. No heredes porcentajes, requisitos o criterios sin verificarlos. Si las bases de la tercera convocatoria no están disponibles, solicita esos documentos y limita la salida a un inventario o análisis exploratorio expresamente provisional.

## Normativa complementaria
Consulta el Manual de Procedimientos de Subvenciones y el Manual SGAS con sus anexos pertinentes. Selecciona las políticas relevantes a las actividades. El manual de marca sirve para comunicación y formato cuando corresponda, no como criterio de factibilidad técnica. Una ficha de proyectos ganadores es antecedente y no una regla de elegibilidad.
