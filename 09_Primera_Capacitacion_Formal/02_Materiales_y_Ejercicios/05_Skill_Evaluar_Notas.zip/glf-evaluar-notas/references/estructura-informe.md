# Estructura del informe Word

Título: Evaluación preliminar de la nota conceptual
Aviso: Borrador para revisión humana del GLF. No constituye aprobación de financiamiento.

1. Identificación y alcance: código, título, proponente, convocatoria, tema, monto solicitado, plazo, fecha de análisis y limitaciones.
2. Fuentes y correspondencia: nota, screening, anexos, normativa, versiones y dudas de vinculación.
3. Síntesis de la intervención: problema, objetivos, actividades, beneficiarios y resultados.
4. Revisión administrativa y normativa: criterio, regla y referencia, evidencia, estado y pendiente.
5. Evaluación técnica: una subsección por criterio vigente. Separa hechos, interpretación y datos faltantes. Muestra pesos solo si corresponden al perfil validado.
6. Contraste con el screening: hallazgo del screening, evidencia de la nota, norma aplicable, conclusión del contraste y acción requerida.
7. Factibilidad preliminar: coherencia técnica, ejecución, recursos, presupuesto, plazo y sostenibilidad con las limitaciones de esta etapa.
8. Recomendación para revisión: resultado razonado, impedimentos, condiciones para la siguiente etapa y preguntas al proponente.
9. Referencias y control: fuente exacta, página PDF o sección/párrafo Word, versión del perfil de convocatoria y espacio para revisor humano.

Usa tablas breves y texto legible. Referencia cada hallazgo material. Para citas Word sin paginación estable usa encabezado y número de párrafo. No inventes páginas.
